using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using CrackerBillingApp.Data;
using CrackerBillingApp.Models;

var builder = WebApplication.CreateBuilder(args);

// Configure Kestrel to listen on all network interfaces on port 5000
builder.WebHost.ConfigureKestrel(options =>
{
    options.Listen(IPAddress.Any, 5000);
});

// Add CORS so API can be consumed flexibly
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(p => p.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod());
});

var app = builder.Build();

app.UseCors();

// Ensure no-cache so the app NEVER runs offline without the terminal server
app.Use(async (context, next) =>
{
    context.Response.Headers["Cache-Control"] = "no-cache, no-store, must-revalidate";
    context.Response.Headers["Pragma"] = "no-cache";
    context.Response.Headers["Expires"] = "0";
    await next();
});

app.UseDefaultFiles();
app.UseStaticFiles();

// Initialize SQLite database
try
{
    DatabaseHelper.InitializeDatabase();
    Console.WriteLine($"[DB] Initialized SQLite at: {DatabaseHelper.CurrentDbPath}");
}
catch (Exception ex)
{
    Console.WriteLine($"[DB ERROR] {ex.Message}");
}

#region Helper: Network IP Detection
static List<string> GetLocalIpAddresses()
{
    var list = new List<string>();
    try
    {
        foreach (var ni in NetworkInterface.GetAllNetworkInterfaces())
        {
            if (ni.OperationalStatus != OperationalStatus.Up ||
                ni.NetworkInterfaceType == NetworkInterfaceType.Loopback)
                continue;

            var props = ni.GetIPProperties();
            foreach (var addr in props.UnicastAddresses)
            {
                if (addr.Address.AddressFamily == AddressFamily.InterNetwork)
                {
                    var ip = addr.Address.ToString();
                    if (!ip.StartsWith("169.254")) // Skip link-local
                    {
                        list.Add(ip);
                    }
                }
            }
        }
    }
    catch { }

    if (list.Count == 0) list.Add("localhost");
    return list;
}
#endregion

#region API Endpoints

// Server status and local IPs for mobile devices
app.MapGet("/api/info", () =>
{
    var ips = GetLocalIpAddresses();
    return Results.Ok(new
    {
        appName = "Diwali Crackers POS & Billing",
        version = "2.0 (Mobile & Desktop)",
        dbPath = DatabaseHelper.CurrentDbPath,
        dbFileName = Path.GetFileName(DatabaseHelper.CurrentDbPath),
        localIps = ips,
        port = 5000,
        mobileUrl = $"http://{ips.FirstOrDefault() ?? "localhost"}:5000"
    });
});

// Communities
app.MapGet("/api/communities", () =>
{
    try
    {
        return Results.Ok(DatabaseHelper.GetCommunities());
    }
    catch (Exception ex)
    {
        return Results.Problem(ex.Message);
    }
});

app.MapPost("/api/communities", (CommunityDto dto) =>
{
    try
    {
        if (string.IsNullOrWhiteSpace(dto.Name))
            return Results.BadRequest(new { error = "Community name is required." });

        int id = DatabaseHelper.AddCommunity(dto.Name.Trim(), dto.Description?.Trim() ?? "");
        return Results.Ok(new { id, message = $"Community '{dto.Name}' added successfully." });
    }
    catch (Exception ex)
    {
        return Results.BadRequest(new { error = ex.Message });
    }
});

app.MapDelete("/api/communities/{id:int}", (int id) =>
{
    try
    {
        DatabaseHelper.DeleteCommunity(id);
        return Results.Ok(new { message = "Community deleted." });
    }
    catch (Exception ex)
    {
        return Results.BadRequest(new { error = ex.Message });
    }
});

// Master Items & Stock
app.MapGet("/api/items", (string? search) =>
{
    try
    {
        var items = DatabaseHelper.GetItems(search ?? "");
        return Results.Ok(items);
    }
    catch (Exception ex)
    {
        return Results.Problem(ex.Message);
    }
});

app.MapPost("/api/items", (ItemCreateDto dto) =>
{
    try
    {
        if (string.IsNullOrWhiteSpace(dto.Name))
            return Results.BadRequest(new { error = "Item name is required." });

        int id = DatabaseHelper.AddItem(
            dto.Code?.Trim() ?? "",
            dto.Name.Trim(),
            dto.Category?.Trim() ?? "General",
            dto.TotalBoxes,
            dto.DefaultPrice);

        return Results.Ok(new { id, message = $"Item '{dto.Name}' added successfully." });
    }
    catch (Exception ex)
    {
        return Results.BadRequest(new { error = ex.Message });
    }
});

app.MapPost("/api/items/{id:int}/restock", (int id, RestockDto dto) =>
{
    try
    {
        if (dto.Boxes <= 0)
            return Results.BadRequest(new { error = "Quantity must be greater than 0." });

        DatabaseHelper.AddStockBoxes(id, dto.Boxes);
        return Results.Ok(new { message = $"Added {dto.Boxes} boxes to item ID {id}." });
    }
    catch (Exception ex)
    {
        return Results.BadRequest(new { error = ex.Message });
    }
});

app.MapPut("/api/items/{id:int}", (int id, ItemUpdateDto dto) =>
{
    try
    {
        DatabaseHelper.UpdateItemDetails(id, dto.Name, dto.Category, dto.DefaultPrice);
        return Results.Ok(new { message = "Item details updated successfully." });
    }
    catch (Exception ex)
    {
        return Results.BadRequest(new { error = ex.Message });
    }
});

// Community Pricing
app.MapGet("/api/community-prices", (int communityId, string? search) =>
{
    try
    {
        var items = DatabaseHelper.GetCommunityPricedItems(communityId, search ?? "");
        return Results.Ok(items);
    }
    catch (Exception ex)
    {
        return Results.Problem(ex.Message);
    }
});

app.MapPost("/api/community-prices", (CommunityPriceUpdateDto dto) =>
{
    try
    {
        DatabaseHelper.SetCommunityPrice(dto.CommunityId, dto.ItemId, dto.Price);
        return Results.Ok(new { message = "Price saved." });
    }
    catch (Exception ex)
    {
        return Results.BadRequest(new { error = ex.Message });
    }
});

// Sales & Billing Counter
app.MapPost("/api/sales", (SaleRequestDto dto) =>
{
    try
    {
        if (dto.Items == null || dto.Items.Count == 0)
            return Results.BadRequest(new { error = "Cart is empty. Please add items." });

        var cartItems = dto.Items.Select(i => new CartItem
        {
            ItemId = i.ItemId,
            ItemName = i.ItemName,
            Category = i.Category ?? "",
            UnitPrice = i.UnitPrice,
            Quantity = i.Quantity,
            MaxStock = i.MaxStock
        }).ToList();

        var saleRecord = DatabaseHelper.ProcessSale(
            dto.CommunityId,
            dto.CommunityName ?? "General Retail",
            dto.CustomerName ?? "Counter Customer",
            dto.CustomerPhone ?? "",
            dto.PaymentMode ?? "Hand Cash",
            cartItems);

        return Results.Ok(saleRecord);
    }
    catch (InvalidOperationException ex)
    {
        return Results.BadRequest(new { error = ex.Message });
    }
    catch (Exception ex)
    {
        return Results.Problem(ex.Message);
    }
});

app.MapGet("/api/sales", (string? filter) =>
{
    try
    {
        var history = DatabaseHelper.GetSalesHistory(filter ?? "All");
        return Results.Ok(history);
    }
    catch (Exception ex)
    {
        return Results.Problem(ex.Message);
    }
});

app.MapGet("/api/sales/{id:int}/items", (int id) =>
{
    try
    {
        var items = DatabaseHelper.GetSaleItems(id);
        return Results.Ok(items);
    }
    catch (Exception ex)
    {
        return Results.Problem(ex.Message);
    }
});

// Stock & Sales Summary Dashboard
app.MapGet("/api/dashboard/summary", () =>
{
    try
    {
        var summary = DatabaseHelper.GetStockSummary();
        return Results.Ok(summary);
    }
    catch (Exception ex)
    {
        return Results.Problem(ex.Message);
    }
});

// Customers
app.MapGet("/api/customers", () =>
{
    try
    {
        var customers = DatabaseHelper.GetCustomers();
        return Results.Ok(customers);
    }
    catch (Exception ex)
    {
        return Results.Problem(ex.Message);
    }
});

// Commission Price List
app.MapGet("/api/commission-list", (int communityId, string? search) =>
{
    try
    {
        var items = DatabaseHelper.GetCommissionList(communityId, search ?? "");
        return Results.Ok(items);
    }
    catch (Exception ex)
    {
        return Results.Problem(ex.Message);
    }
});

#endregion

Console.WriteLine("=================================================");
Console.WriteLine("🎇 DIWALI CRACKERS MOBILE & DESKTOP POS SERVER 🎇");
Console.WriteLine("=================================================");
var ips = GetLocalIpAddresses();
Console.WriteLine("Access this app on any device:");
Console.WriteLine($"  - Local PC:       http://localhost:5000");
foreach (var ip in ips)
{
    Console.WriteLine($"  - Android Phone:  http://{ip}:5000");
}
Console.WriteLine("=================================================");

app.Run();

#region DTOs
public record CommunityDto(string Name, string? Description);
public record ItemCreateDto(string? Code, string Name, string? Category, int TotalBoxes, decimal DefaultPrice);
public record ItemUpdateDto(string Name, string Category, decimal DefaultPrice);
public record RestockDto(int Boxes);
public record CommunityPriceUpdateDto(int CommunityId, int ItemId, decimal Price);
public record SaleRequestItemDto(int ItemId, string ItemName, string? Category, decimal UnitPrice, int Quantity, int MaxStock);
public record SaleRequestDto(
    int CommunityId,
    string? CommunityName,
    string? CustomerName,
    string? CustomerPhone,
    string? PaymentMode,
    List<SaleRequestItemDto> Items);
#endregion
