# 🎆 Diwali Crackers Mobile POS & Stock System (PWA for Android & Desktop)

A touch-optimized, cross-platform Progressive Web Application (PWA) and offline server that allows you to manage cracker inventories, community pricing, generate bills, and process payments directly from your **Android mobile phone, tablet, or PC**.

---

## 🚀 How to Run and Open on Android

### Step 1: Start the POS Server on your PC
Double-click:
`Launch_Android_POS_Server.bat`

This starts the server and opens your browser. It also displays your PC's local Wi-Fi IP address (e.g. `192.168.1.8`).

---

### Step 2: Open on Android Phone / Tablet
1. Make sure your Android phone is connected to the **same Wi-Fi router** or your **phone's mobile hotspot**.
2. Open **Google Chrome** on your Android phone.
3. Type the address shown in the console:
   ```text
   http://192.168.1.8:5000
   ```
4. You are ready to start billing!

---

### Step 3: Install as an App on Android (Home Screen Icon)
1. In Google Chrome on your phone, tap the **top-right menu (⋮ 3 dots)**.
2. Tap **"Install app"** or **"Add to Home screen"**.
3. Tap **Install**.
4. The **Diwali Crackers POS** icon 🎆 will now appear on your phone home screen just like a native Android APK!
   - Opens in **fullscreen** without any URL bar.
   - Works fast with offline caching.

---

## 🌟 Key Features

1. **🏢 Community-Specific Pricing**:
   - Choose any community (e.g. *Green Meadows Society*, *Royal Palms*, *Wholesale*, *General Retail*).
   - Instantly adjusts all cracker rates.
   - Add new communities directly from your phone.

2. **🛒 Mobile Billing Counter**:
   - Search crackers by name or code.
   - Category filter pills (*Sparklers*, *Flower Pots*, *Chakkars*, *Rockets*, etc.).
   - Visual Remaining Stock indicators (Green = In Stock, Orange = Low, Red = Sold Out).
   - Prevents over-selling beyond available stock.
   - Select payment mode: **💵 Hand Cash** or **📱 PhonePe / UPI**.
   - Generates itemized invoices with automatic stock subtraction.

3. **🧾 Instant Receipt Actions**:
   - **🖨️ Print Receipt**: Ready for mobile Bluetooth thermal POS printers (58mm/80mm) and standard printers.
   - **💬 Share via WhatsApp**: 1-tap WhatsApp message generation with full itemized bill text to customer's number.
   - **📋 Copy Text**: Copies clean receipt breakdown to clipboard.

4. **📦 Real-Time Stock & Sales Dashboard**:
   - Live KPI cards: Total Boxes, Used Boxes, Remaining Boxes, Hand Cash Sales (₹), PhonePe Sales (₹), and Grand Sales (₹).
   - Instant Restock button: Add extra inventory directly from the phone counter.

5. **🔄 Shared Database with Desktop App**:
   - Connects to the same SQLite database (`crackers_store.db`).
   - Any sale made from your Android phone instantly updates the stock on the Windows PC, and vice-versa!
