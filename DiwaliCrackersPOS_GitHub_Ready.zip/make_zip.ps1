$src = 'C:\Users\venky\.gemini\antigravity\scratch\CrackerBillingWeb'
$zip = 'C:\Users\venky\.gemini\antigravity\scratch\DiwaliCrackersPOS_GitHub_Ready.zip'
if (Test-Path $zip) { Remove-Item $zip -Force }

$tmp = Join-Path $env:TEMP ('pos_pkg_' + [Guid]::NewGuid().ToString())
New-Item -ItemType Directory -Path $tmp -Force | Out-Null

$items = Get-ChildItem -Path $src | Where-Object { $_.Name -notin @('bin','obj','publish','tunnel.log','cloudflared.exe') }
foreach ($i in $items) {
    Copy-Item -Path $i.FullName -Destination $tmp -Recurse -Force
}

Compress-Archive -Path ($tmp + '\*') -DestinationPath $zip -Force
Remove-Item -Path $tmp -Recurse -Force
Write-Host "SUCCESS: Created $zip"
