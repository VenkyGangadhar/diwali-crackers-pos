# ☁️ How to Run 24/7 in the Cloud (Zero PC / Zero Terminal Needed)

You have two powerful options to run this app without keeping your PC or terminal open:

---

## 🌟 Solution 1: Standalone Phone Mode (Runs Directly on Phone, 0% PC Needed)
**Best if you want to sell crackers immediately on your phone without touching a PC:**

1. Open this link on your phone in **Google Chrome**:
   ```
   https://carolina-vpn-dynamic-stones.trycloudflare.com
   ```
2. Tap **"📲 Download App"** at the top or Chrome Menu (3 dots) → **"Install app"** / **"Add to Home screen"**.
3. Once installed on your phone home screen, **you can turn off your PC completely**.
4. When you open the app on your phone with your PC off, simply tap:
   > **`📱 Open Standalone Phone Mode`**
5. All **106 items from Quotation 1137** (Sri Vijayalaxmi Fire Works) are pre-loaded in your phone's memory.
6. You can add items to cart, issue bills, deduct stock, print thermal receipts, view commission, and export PDFs directly on your phone!

---

## 🚀 Solution 2: Free 24/7 Cloud Hosting on Render (Always Online, Accessible Anywhere)
**Best if you want a permanent link that never changes and multiple phones can bill at the same time:**

### 3-Step Setup (Takes 3 Minutes, 100% Free):
1. **Create Free Account:** Go to [https://render.com](https://render.com) and sign up for a free account.
2. **Push Code to GitHub:**
   - Create a free GitHub repository (e.g. `diwali-crackers-pos`).
   - Upload the project files from `C:\Users\venky\.gemini\antigravity\scratch\CrackerBillingWeb`.
3. **Deploy Web Service on Render:**
   - Click **New +** → **Web Service**.
   - Select your GitHub repository.
   - Environment: **Docker** (it automatically uses the included `Dockerfile` and `render.yaml`).
   - Click **Deploy Web Service**.
4. **Done!** Render gives you a permanent 24/7 link like:
   ```
   https://diwali-crackers-pos.onrender.com
   ```
   This link works permanently without your PC or terminal running!
