@echo off
title Diwali Crackers POS Server - Mobile & Desktop
color 0E

echo ================================================================
echo        DIWALI CRACKERS BILLING & STOCK SYSTEM (POS)
echo           Mobile Android Web App & Local POS Server
echo ================================================================
echo.

:: Get Local IP Address
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /i "IPv4" ^| findstr /v "169.254"') do (
    set IP=%%a
    goto :found_ip
)

:found_ip
set IP=%IP: =%
echo [INFO] Detected Local Network IP: %IP%
echo.
echo ================================================================
echo   HOW TO OPEN ON YOUR ANDROID PHONE / TABLET:
echo.
echo   1. Connect your phone to the same Wi-Fi router / Hotspot
echo   2. Open Google Chrome on your phone
echo   3. Type this URL into the Chrome address bar:
echo.
echo          http://%IP%:5000
echo.
echo   4. Tap Chrome Menu (3 dots) -^> "Install app" or "Add to Home screen"
echo      The app icon will appear on your phone home screen!
echo ================================================================
echo.
echo [INFO] Starting POS Server on port 5000...
echo [INFO] Press Ctrl+C anytime to stop the server.
echo.

:: Start PC Browser after 2 seconds
start "" cmd /c "timeout /t 2 /nobreak >nul & start http://localhost:5000"

:: Run Server
cd /d "%~dp0"
if exist "publish\CrackerBillingWeb.exe" (
    "publish\CrackerBillingWeb.exe"
) else (
    dotnet run
)

pause
