@echo off
title Diwali Crackers POS - Online Anywhere Launcher
powershell -ExecutionPolicy Bypass -File "%~dp0start-online-pos.ps1"
pause
