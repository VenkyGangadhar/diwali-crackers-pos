# Parse and Import Sri Vijayalaxmi Fire Works Quotation No. 1137
$csvData = @"
No,Particulars,Qty,Pieces,Rate,CostPerPiece,Amount,SellingPrice
1,3½ Laxmi,8,80,90,9,720,16.5
2,4" Laxmi,5,50,140,14,700,27.5
3,4" DLX,6,60,240,24,1440,44
4,4" Gold,5,50,250,25,1250,44
5,28 Giant,8,80,450,45,3600,90
6,24 Deluxe,5,50,300,30,1500,60
7,100 Deluxe,10,10,135,135,1350,270
8,50 Deluxe,10,10,60,60,600,120
9,2 Sound,10,100,150,15,1500,30
10,5" Ganesh,25,25,35,35,875,66
11,Tiger DLX,20,20,190,190,3800,400
12,Saddam,30,30,60,60,1800,132
13,Cat Deluxe,50,50,140,140,7000,275
14,Nasi,20,20,125,125,2500,220
15,100 Wala,30,30,30,30,900,60
16,200 Wala,30,30,60,60,1800,120
17,10 CM,30,30,14,14,420,27.5
18,15 CM,125,26,26,125,3250,55
19,30 CM,200,200,26,26,5200,55
20,15 CM (C),125,125,28,28,3500,60.5
21,30 CM (C),100,28,28,100,2800,60.5
22,Drone,20,20,100,100,2000,200
23,STD Tri Color,20,20,302,302,6040,605
24,505 Guns,40,40,42,42,1680,84
25,RC 35 GUNs,40,40,18,18,720,36
26,303 Guns,40,40,40,40,1600,80
27,Alto,40,40,20,20,800,40
28,5 in 1,20,20,60,60,1200,120
29,Music Wand,10,10,130,130,1300,260
30,Long Way,5,5,505,505,2525,1010
31,3 Piece 2 inch Short,10,30,240,80,2400,160
32,Little Bee,20,20,320,320,6400,640
33,50 CM,20,20,100,100,2000,220
34,12 CM,100,100,17,17,1700,34
35,12 CM (E),100,100,18,18,1800,36
36,Ground Chakra Deluxe,30,30,90,90,2700,187
37,Ground Chakra Special,20,20,60,60,1200,110
38,Ground Chakra Ashoka,20,20,45,45,900,154
39,Ground Chakra Big,20,20,30,30,600,55
40,Spinner Spl Vanith,30,30,210,210,6300,420
41,Baby Rocket,20,20,29,29,580,44
42,Colour Rocket,20,20,45,45,900,99
43,Rocket Bomb,20,20,50,50,1000,88
44,2 Sound Rocket,20,20,78,78,1560,148.5
45,Whisle Rocket,10,10,150,150,1500,300
46,Zip Wala Rocket,10,10,180,180,1800,360
47,Hip Hop,20,20,20,20,400,40
48,Kit Kat,30,30,20,20,600,40
49,Flower Pot Special,30,30,58,58,1740,121
50,Flower Pot Ashoka Vanitha,20,20,300,300,6000,600
51,Flower Pot Ashoka,40,40,80,80,3200,154
52,Folower Pot Color Koti,30,30,130,130,3900,260
53,Flower Pot Big,30,30,50,50,1500,88
54,Flower Pot Small,30,30,38,38,1140,55
55,Diet Coke,10,10,75,75,750,150
56,Helicopter,10,10,70,70,700,140
57,Gada,5,5,200,200,1000,400
58,Light House,10,10,180,180,1800,360
59,Free Fire,6,6,162,162,972,324
60,Cylinder,10,10,160,160,1600,320
61,Emoji,1,1,360,360,360,720
62,Guitar,5,5,225,225,1125,450
63,1" Comet,10,10,36,36,360,72
64,Whisky Wheel,20,20,150,150,3000,300
65,Butterfly Vanitha,15,15,160,160,2400,320
66,Hi-5,6,6,373,373,2238,746
67,Peacock Small,10,10,130,130,1300,242
68,Smaily Stick,20,20,235,235,4700,470
69,Threads Small,40,40,20,20,800,55
70,Threads Big,30,30,50,50,1500,110
71,STD Threads Small,20,20,37,37,740,75
72,Gift Pack,3,3,660,660,1980,1320
73,Dazzle,6,6,360,360,2160,720
74,Tim Tim Flower Pot,10,10,280,280,2800,560
75,Mala Gun,10,10,52,52,520,104
76,Ring Cap,300,300,5.5,5.5,1650,11
77,Roll Cap,10,100,55,5.5,550,11
78,Mega Color Koti,30,30,240,240,7200,418
79,Bijili 50,100,100,12,12,1200,30
80,Bijili 100,100,100,25,25,2500,60
81,Bijili red,100,100,22,22,2200,70
82,1000 Wala Half,36,36,110,110,3960,220
83,1000 Wala Full,18,18,150,150,2700,286
84,2000 Wala Half,24,24,220,220,5280,440
85,2000 Wala Full,12,12,300,300,3600,572
86,5000 Wala Half,24,24,750,750,18000,825
87,5000 Wala Full,16,16,550,550,8800,1210
88,10000 Wala Full,5,5,1500,1500,7500,2475
89,12 Shot,20,20,125,125,2500,220
90,15 Shot,30,30,220,220,6600,363
91,30 Shot,36,36,310,310,11160,495
92,60 Shot,24,24,650,650,15600,935
93,120 Shot (M),6,6,1300,1300,7800,2090
94,STD Giant Flower POT,70,70,297,297,20790,605
95,STD Deluxe Flower Pot,40,40,193,193,7720,440
96,STD Ground Chakra Deluxe,100,100,155,155,15500,330
97,STD Ground Chakra Ashoka,140,140,120,120,16800,253
98,STD Red Bijili,180,180,47,47,8460,110
99,STD 30 CM Sparkles,210,210,58,58,12180,132
100,STD 30 CM Gold,210,210,62,62,13020,143
101,STD 15 CM Sparkles,150,150,58,58,8700,132
102,STD 15 CM Gold,150,150,62,62,9300,143
103,Anaconda,10,10,60,60,600,120
104,Popup,3,72,6000,250,18000,500
105,Beedi Bomb,20,20,90,90,1800,180
106,Pencil,100,100,65,65,6500,130
"@

function Get-Category($name) {
    if ($name -match 'Wala|Garland') { return 'Garlands / Wala' }
    if ($name -match 'Laxmi|Sound|Ganesh|Tiger|Saddam|Cat Deluxe|Nasi|Bijili|Beedi') { return 'Sound Crackers' }
    if ($name -match 'Chakra|Spinner|Wheel') { return 'Ground Chakkars' }
    if ($name -match 'Flower Pot|Color Koti|Ashoka') { return 'Flower Pots' }
    if ($name -match 'Rocket|Whisle|Zip') { return 'Rockets' }
    if ($name -match 'Shot|Comet|Drone|Helicopter') { return 'Sky Shots' }
    if ($name -match 'CM|Sparkle|Gold|Pencil|Smaily') { return 'Sparklers' }
    return 'Novelty & Fancy'
}

$lines = $csvData -split "`r?`n" | Select-Object -Skip 1
Write-Host "Found $($lines.Count) items to import from Quotation No. 1137..."

# First create community if not exists
$commName = "Sri Vijayalaxmi (Quotation 1137)"
$commDesc = "Quotation 1137 Customer: Gangadhar Reddy (12/10/2026)"

$communities = Invoke-RestMethod -Uri "http://localhost:5000/api/communities"
$targetComm = $communities | Where-Object { $_.name -eq $commName }
if (-not $targetComm) {
    $res = Invoke-RestMethod -Uri "http://localhost:5000/api/communities" -Method POST `
        -ContentType "application/json" -Body (@{ name = $commName; description = $commDesc } | ConvertTo-Json)
    $commId = $res.id
    Write-Host "Created community '$commName' (ID: $commId)"
} else {
    $commId = $targetComm.id
    Write-Host "Using existing community '$commName' (ID: $commId)"
}

# Also ensure "General Retail" has ID
$generalComm = $communities | Where-Object { $_.name -eq "General Retail" }
$genId = if ($generalComm) { $generalComm.id } else { 1 }

$existingItems = Invoke-RestMethod -Uri "http://localhost:5000/api/items"
$itemDict = @{}
foreach ($item in $existingItems) {
    $itemDict[$item.itemName.Trim().ToLower()] = $item
}

$importedCount = 0
foreach ($line in $lines) {
    if ([string]::IsNullOrWhiteSpace($line)) { continue }
    $parts = $line -split ","
    $num = $parts[0].Trim()
    $name = $parts[1].Trim()
    $pieces = [int]$parts[3].Trim()
    $cost = [decimal]$parts[5].Trim()
    $selling = [decimal]$parts[7].Trim()
    $cat = Get-Category $name
    $code = "SV-" + $num.PadLeft(3, '0')

    $existing = $itemDict[$name.ToLower()]
    if (-not $existing) {
        # Create item
        $payload = @{
            code = $code
            name = $name
            category = $cat
            totalBoxes = $pieces
            defaultPrice = $cost
        }
        $created = Invoke-RestMethod -Uri "http://localhost:5000/api/items" -Method POST `
            -ContentType "application/json" -Body ($payload | ConvertTo-Json)
        $itemId = $created.id
    } else {
        $itemId = $existing.id
    }

    # Set Selling Price for the community
    $pricePayload = @{
        communityId = $commId
        itemId = $itemId
        price = $selling
    }
    Invoke-RestMethod -Uri "http://localhost:5000/api/community-prices" -Method POST `
        -ContentType "application/json" -Body ($pricePayload | ConvertTo-Json) | Out-Null

    # Also set for General Retail so user sees it right away
    if ($genId) {
        $genPricePayload = @{
            communityId = $genId
            itemId = $itemId
            price = $selling
        }
        Invoke-RestMethod -Uri "http://localhost:5000/api/community-prices" -Method POST `
            -ContentType "application/json" -Body ($genPricePayload | ConvertTo-Json) | Out-Null
    }

    $importedCount++
}

Write-Host "Successfully processed $importedCount items with Cost and Selling Prices!" -ForegroundColor Green
