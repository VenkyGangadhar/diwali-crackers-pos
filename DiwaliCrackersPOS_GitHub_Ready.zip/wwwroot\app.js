/* ===================================================
   DIWALI CRACKERS POS & BILLING SYSTEM - JAVASCRIPT
   =================================================== */

// Global State
const state = {
  communities: [],
  selectedCommunityId: null,
  selectedCommunityName: '',
  pricedItems: [],
  cart: [],
  activeCategory: 'ALL',
  searchQuery: '',
  deferredInstallPrompt: null,
  currentReceipt: null,
  networkInfo: null,
  isPhoneMode: false
};

/* ================= PHONE STANDALONE STORE (ZERO PC MODE) ================= */
const PhoneStore = {
  isPhoneMode: false,

  async init() {
    this.isPhoneMode = true;
    state.isPhoneMode = true;

    if (!localStorage.getItem('POS_PHONE_ITEMS')) {
      try {
        const res = await fetch('/default_catalog.json');
        if (res.ok) {
          const items = await res.json();
          localStorage.setItem('POS_PHONE_ITEMS', JSON.stringify(items));
        }
      } catch (e) { }
    }

    if (!localStorage.getItem('POS_PHONE_COMMUNITIES')) {
      const comms = [
        { id: 1, name: "Sri Vijayalaxmi (Quotation 1137)", description: "Customer: Gangadhar Reddy (12/10/2026)" },
        { id: 2, name: "General Retail", description: "Standard walk-in customers" },
        { id: 3, name: "Wholesale / Bulk Buyers", description: "Festival bulk rates" }
      ];
      localStorage.setItem('POS_PHONE_COMMUNITIES', JSON.stringify(comms));
    }

    if (!localStorage.getItem('POS_PHONE_SALES')) {
      localStorage.setItem('POS_PHONE_SALES', JSON.stringify([]));
    }

    const badge = document.getElementById('txtNetworkStatus');
    if (badge) {
      badge.textContent = '📱 Phone Mode (No PC Needed)';
      badge.style.color = '#38bdf8';
    }
    closeModal('modalServerOffline');
  },

  getCommunities() {
    try {
      return JSON.parse(localStorage.getItem('POS_PHONE_COMMUNITIES')) || [];
    } catch { return []; }
  },

  getItems(search = '') {
    try {
      const items = JSON.parse(localStorage.getItem('POS_PHONE_ITEMS')) || [];
      const q = (search || '').toLowerCase().trim();
      return items.filter(i => !q || i.itemName.toLowerCase().includes(q) || (i.itemCode && i.itemCode.toLowerCase().includes(q)) || (i.category && i.category.toLowerCase().includes(q)));
    } catch { return []; }
  },

  getCommunityPrices(communityId, search = '') {
    const items = this.getItems(search);
    return items.map(i => ({
      itemId: i.itemId,
      itemCode: i.itemCode,
      itemName: i.itemName,
      category: i.category,
      remainingStock: i.remainingStock,
      totalStock: i.remainingStock,
      price: i.sellingPrice || i.costPrice,
      costPrice: i.costPrice,
      sellingPrice: i.sellingPrice || i.costPrice,
      commissionAmount: (i.sellingPrice || i.costPrice) - i.costPrice,
      commissionPercent: i.costPrice > 0 ? (((i.sellingPrice || i.costPrice) - i.costPrice) / i.costPrice) * 100 : 0
    }));
  },

  setCommunityPrice(communityId, itemId, price) {
    const items = this.getItems();
    const item = items.find(i => i.itemId === itemId);
    if (item) {
      item.sellingPrice = price;
      item.commissionAmount = price - item.costPrice;
      item.commissionPercent = item.costPrice > 0 ? (item.commissionAmount / item.costPrice) * 100 : 0;
      localStorage.setItem('POS_PHONE_ITEMS', JSON.stringify(items));
    }
  },

  processSale(saleDto) {
    const items = this.getItems();
    const sales = JSON.parse(localStorage.getItem('POS_PHONE_SALES')) || [];
    let totalAmt = 0;
    let totalBoxes = 0;
    const saleItems = [];

    saleDto.items.forEach(c => {
      const dbItem = items.find(i => i.itemId === c.itemId);
      if (dbItem) {
        dbItem.remainingStock = Math.max(0, dbItem.remainingStock - c.quantity);
      }
      const itemTot = c.unitPrice * c.quantity;
      totalAmt += itemTot;
      totalBoxes += c.quantity;
      saleItems.push({
        id: Date.now() + Math.random(),
        itemId: c.itemId,
        itemName: c.itemName,
        quantity: c.quantity,
        unitPrice: c.unitPrice,
        totalPrice: itemTot
      });
    });

    localStorage.setItem('POS_PHONE_ITEMS', JSON.stringify(items));

    const timestamp = new Date();
    const billNumber = `INV-${timestamp.getFullYear()}${String(timestamp.getMonth()+1).padStart(2,'0')}${String(timestamp.getDate()).padStart(2,'0')}-${Math.floor(1000 + Math.random()*9000)}`;

    const saleRecord = {
      id: Date.now(),
      billNumber: billNumber,
      communityName: saleDto.communityName || 'Sri Vijayalaxmi (Quotation 1137)',
      customerName: saleDto.customerName || 'Gangadhar Reddy',
      customerPhone: saleDto.customerPhone || '-',
      totalAmount: totalAmt,
      paymentMode: saleDto.paymentMode || 'Hand Cash',
      createdAt: timestamp.toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }),
      totalBoxesSold: totalBoxes,
      totalItemsCount: saleDto.items.length,
      items: saleItems
    };

    sales.unshift(saleRecord);
    localStorage.setItem('POS_PHONE_SALES', JSON.stringify(sales));
    return saleRecord;
  },

  getSalesHistory(filter = 'All') {
    const sales = JSON.parse(localStorage.getItem('POS_PHONE_SALES')) || [];
    if (filter === 'All') return sales;
    return sales.filter(s => (s.paymentMode || '').toLowerCase().includes(filter.toLowerCase()));
  },

  getSummary() {
    const items = this.getItems();
    const sales = JSON.parse(localStorage.getItem('POS_PHONE_SALES')) || [];
    const totalBoxes = items.reduce((s, i) => s + (i.remainingStock || 0), 0);
    const totalSales = sales.reduce((s, b) => s + (b.totalAmount || 0), 0);
    const handCash = sales.filter(b => (b.paymentMode || '').toLowerCase().includes('cash')).reduce((s, b) => s + b.totalAmount, 0);
    const phonePe = sales.filter(b => (b.paymentMode || '').toLowerCase().includes('phone') || (b.paymentMode || '').toLowerCase().includes('upi')).reduce((s, b) => s + b.totalAmount, 0);

    let totalComm = 0;
    sales.forEach(s => {
      s.items.forEach(si => {
        const item = items.find(i => i.itemId === si.itemId);
        const cost = item ? item.costPrice : 0;
        totalComm += (si.totalPrice - (si.quantity * cost));
      });
    });

    return {
      totalBoxes,
      usedBoxes: sales.reduce((s, b) => s + b.totalBoxesSold, 0),
      remainingBoxes: totalBoxes,
      totalSales,
      handCashSales: handCash,
      phonePeSales: phonePe,
      totalBillsCount: sales.length,
      totalCommissionEarned: Math.max(0, totalComm)
    };
  }
};

// DOM Content Loaded Entry Point
document.addEventListener('DOMContentLoaded', async () => {
  initServiceWorker();
  initInstallPrompt();
  initNavigation();
  initModals();
  initAudio();
  
  await fetchNetworkInfo();
  await loadCommunities();

  // Heartbeat to ensure terminal server is strictly online
  if (!heartbeatInterval) {
    heartbeatInterval = setInterval(fetchNetworkInfo, 3500);
  }
});

/* ================= SERVICE WORKER & PWA INSTALL ================= */
function initServiceWorker() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/service-worker.js')
      .then(() => console.log('[PWA] Service Worker Active (Phone Mode Ready)'))
      .catch(err => console.log('[PWA] SW register:', err));
  }
}

function initInstallPrompt() {
  const btnInstall = document.getElementById('btnInstallPwa');
  if (!btnInstall) return;

  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    state.deferredInstallPrompt = e;
  });

  btnInstall.addEventListener('click', async () => {
    if (state.deferredInstallPrompt) {
      state.deferredInstallPrompt.prompt();
      const { outcome } = await state.deferredInstallPrompt.userChoice;
      console.log('[PWA] Install choice:', outcome);
      state.deferredInstallPrompt = null;
    } else {
      // Open Phone / Anywhere access modal
      openModal('modalNetwork');
    }
  });
}

/* ================= WEB AUDIO BEEP ================= */
let audioCtx = null;
function initAudio() {
  // AudioContext will be lazily created on first user interaction
}

function playSuccessBeep() {
  try {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain);
    gain.connect(audioCtx.destination);

    osc.type = 'sine';
    osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
    osc.frequency.setValueAtTime(880, audioCtx.currentTime + 0.08); // A5
    gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.25);

    osc.start(audioCtx.currentTime);
    osc.stop(audioCtx.currentTime + 0.25);
  } catch (e) {
    // Audio context may be blocked by browser policy; silently ignore
  }
}

/* ================= NAVIGATION TABS ================= */
function initNavigation() {
  const desktopTabs = document.querySelectorAll('.desktop-nav .nav-tab');
  const mobileTabs = document.querySelectorAll('.mobile-bottom-nav .mobile-tab-btn');

  function switchTab(tabId) {
    document.querySelectorAll('.tab-pane').forEach(el => el.classList.remove('active'));
    desktopTabs.forEach(el => el.classList.remove('active'));
    mobileTabs.forEach(el => el.classList.remove('active'));

    const activePane = document.getElementById(`tab-${tabId}`);
    if (activePane) activePane.classList.add('active');

    document.querySelectorAll(`[data-tab="${tabId}"]`).forEach(el => el.classList.add('active'));

    // Trigger tab-specific refresh
    if (tabId === 'billing') {
      navigator.vibrate?.(20);
    }
    if (tabId === 'stock') loadStockDashboard();
    if (tabId === 'pricing') loadPricingTab();
    if (tabId === 'commission') loadCommissionTab();
    if (tabId === 'catalog') loadCatalogTab();
    if (tabId === 'history') loadSalesHistory('All');
  }

  desktopTabs.forEach(btn => {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
  });

  mobileTabs.forEach(btn => {
    btn.addEventListener('click', () => {
      navigator.vibrate?.(25);
      switchTab(btn.dataset.tab);
    });
  });
}

/* ================= NETWORK & PHONE CONNECTION INFO ================= */
let heartbeatInterval = null;

async function fetchNetworkInfo() {
  if (PhoneStore.isPhoneMode) {
    const btnStatus = document.getElementById('txtNetworkStatus');
    if (btnStatus) {
      btnStatus.textContent = '📱 Phone Standalone Mode (Active)';
      btnStatus.style.color = '#38bdf8';
    }
    return;
  }

  try {
    const res = await fetch('/api/info', { cache: 'no-store' });
    if (!res.ok) throw new Error('Terminal server returned error');
    const data = await res.json();
    state.networkInfo = data;

    const btnStatus = document.getElementById('txtNetworkStatus');
    const phoneUrl = data.mobileUrl || `http://${window.location.hostname}:5000`;
    if (btnStatus) btnStatus.textContent = `🟢 Terminal Online (${data.dbFileName})`;

    const lblPhone = document.getElementById('lblPhoneUrl');
    if (lblPhone) lblPhone.textContent = phoneUrl;

    // Server is reachable, dismiss offline screen if open
    closeModal('modalServerOffline');
  } catch (err) {
    const btnStatus = document.getElementById('txtNetworkStatus');
    if (btnStatus) btnStatus.textContent = '🔴 Terminal Offline';
    openModal('modalServerOffline');
  }
}

/* ================= LOAD COMMUNITIES ================= */
async function loadCommunities() {
  try {
    let list;
    if (PhoneStore.isPhoneMode) {
      list = PhoneStore.getCommunities();
    } else {
      const res = await fetch('/api/communities');
      if (!res.ok) throw new Error('Failed to load communities');
      list = await res.json();
    }
    state.communities = list;

    const selectEl = document.getElementById('selectCommunity');
    const pricingSelectEl = document.getElementById('selectPricingCommunity');
    const commissionSelectEl = document.getElementById('selectCommissionCommunity');
    selectEl.innerHTML = '';
    pricingSelectEl.innerHTML = '';
    if (commissionSelectEl) commissionSelectEl.innerHTML = '';

    list.forEach((c) => {
      const opt = document.createElement('option');
      opt.value = c.id;
      opt.textContent = `${c.name} ${c.description ? '(' + c.description + ')' : ''}`;
      selectEl.appendChild(opt);

      const opt2 = opt.cloneNode(true);
      pricingSelectEl.appendChild(opt2);

      if (commissionSelectEl) {
        const opt3 = opt.cloneNode(true);
        commissionSelectEl.appendChild(opt3);
      }
    });

    if (list.length > 0) {
      state.selectedCommunityId = list[0].id;
      state.selectedCommunityName = list[0].name;
      await loadCommunityPricedItems();
    }

    selectEl.addEventListener('change', async (e) => {
      state.selectedCommunityId = parseInt(e.target.value);
      const comm = state.communities.find(c => c.id === state.selectedCommunityId);
      state.selectedCommunityName = comm ? comm.name : 'General';
      await loadCommunityPricedItems();
    });

    if (commissionSelectEl) {
      commissionSelectEl.addEventListener('change', () => {
        loadCommissionTab();
      });
    }

  } catch (err) {
    console.error('Error loading communities:', err);
  }
}

/* ================= LOAD PRICED ITEMS FOR BILLING ================= */
async function loadCommunityPricedItems() {
  if (!state.selectedCommunityId) return;
  const gridEl = document.getElementById('itemsGrid');
  gridEl.innerHTML = '<div class="loading-spinner">Fetching community prices...</div>';

  try {
    let items;
    if (PhoneStore.isPhoneMode) {
      items = PhoneStore.getCommunityPrices(state.selectedCommunityId);
    } else {
      const res = await fetch(`/api/community-prices?communityId=${state.selectedCommunityId}`);
      if (!res.ok) throw new Error('Failed to load priced items');
      items = await res.json();
    }
    state.pricedItems = items;

    setupCategoryPills(items);
    renderBillingItems();
  } catch (err) {
    if (PhoneStore.isPhoneMode) {
      const items = PhoneStore.getCommunityPrices(state.selectedCommunityId);
      state.pricedItems = items;
      setupCategoryPills(items);
      renderBillingItems();
    } else {
      gridEl.innerHTML = `<div class="error-msg">Error loading crackers: ${err.message}</div>`;
    }
  }
}

function setupCategoryPills(items) {
  const categories = ['ALL', ...new Set(items.map(i => i.category).filter(Boolean))];
  const pillsContainer = document.getElementById('categoryPills');
  pillsContainer.innerHTML = '';

  categories.forEach(cat => {
    const btn = document.createElement('button');
    btn.className = `pill ${cat === state.activeCategory ? 'active' : ''}`;
    btn.dataset.category = cat;
    btn.textContent = cat === 'ALL' ? 'All Crackers' : cat;
    btn.addEventListener('click', () => {
      state.activeCategory = cat;
      document.querySelectorAll('#categoryPills .pill').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      renderBillingItems();
    });
    pillsContainer.appendChild(btn);
  });
}

function renderBillingItems() {
  const gridEl = document.getElementById('itemsGrid');
  const search = state.searchQuery.toLowerCase().trim();

  const filtered = state.pricedItems.filter(item => {
    const matchesCat = state.activeCategory === 'ALL' || item.category === state.activeCategory;
    const matchesSearch = !search || 
      item.itemName.toLowerCase().includes(search) || 
      (item.itemCode && item.itemCode.toLowerCase().includes(search)) ||
      (item.category && item.category.toLowerCase().includes(search));
    return matchesCat && matchesSearch;
  });

  if (filtered.length === 0) {
    gridEl.innerHTML = '<div class="text-center text-muted mt-4">No crackers found matching your criteria.</div>';
    return;
  }

  gridEl.innerHTML = '';

  filtered.forEach(item => {
    const card = document.createElement('div');
    const isOut = item.remainingStock <= 0;
    const isLow = item.remainingStock > 0 && item.remainingStock <= 10;
    
    card.className = `item-card ${isOut ? 'out-of-stock' : ''}`;

    let badgeClass = 'in-stock';
    let badgeText = `${item.remainingStock} boxes`;
    if (isOut) {
      badgeClass = 'out-of-stock';
      badgeText = 'Sold Out';
    } else if (isLow) {
      badgeClass = 'low-stock';
      badgeText = `${item.remainingStock} left (Low)`;
    }

    card.innerHTML = `
      <div>
        <div class="card-top">
          <span class="item-code">${item.itemCode || 'CRK'}</span>
          <span class="category-badge">${item.category || 'General'}</span>
        </div>
        <h3 class="item-name">${item.itemName}</h3>
        <div class="card-stock-row">
          <span class="stock-badge ${badgeClass}">${badgeText}</span>
        </div>
      </div>
      <div class="card-bottom">
        <div class="price-display">
          <span class="price-label">Price / Box</span>
          <span class="price-val">₹${item.price.toFixed(2)}</span>
        </div>
        <div class="card-stepper">
          <button class="stepper-btn btn-minus" ${isOut ? 'disabled' : ''}>-</button>
          <span class="stepper-qty">1</span>
          <button class="stepper-btn btn-plus" ${isOut ? 'disabled' : ''}>+</button>
          <button class="btn-add-cart" ${isOut ? 'disabled' : ''}>+ Add</button>
        </div>
      </div>
    `;

    // Stepper logic
    const minusBtn = card.querySelector('.btn-minus');
    const plusBtn = card.querySelector('.btn-plus');
    const qtySpan = card.querySelector('.stepper-qty');
    const addBtn = card.querySelector('.btn-add-cart');

    let curQty = 1;

    minusBtn?.addEventListener('click', () => {
      if (curQty > 1) {
        curQty--;
        qtySpan.textContent = curQty;
      }
    });

    plusBtn?.addEventListener('click', () => {
      if (curQty < item.remainingStock) {
        curQty++;
        qtySpan.textContent = curQty;
      } else {
        alert(`Cannot add more than ${item.remainingStock} available boxes for this item!`);
      }
    });

    addBtn?.addEventListener('click', () => {
      if (isOut) return;
      addToCart(item, curQty);
      curQty = 1;
      qtySpan.textContent = 1;
    });

    gridEl.appendChild(card);
  });
}

// Search input handling
const searchInput = document.getElementById('inputSearchCrackers');
const clearSearchBtn = document.getElementById('btnClearSearch');

searchInput.addEventListener('input', (e) => {
  state.searchQuery = e.target.value;
  if (state.searchQuery.length > 0) {
    clearSearchBtn.classList.remove('hidden');
  } else {
    clearSearchBtn.classList.add('hidden');
  }
  renderBillingItems();
});

clearSearchBtn.addEventListener('click', () => {
  searchInput.value = '';
  state.searchQuery = '';
  clearSearchBtn.classList.add('hidden');
  renderBillingItems();
});

/* ================= CART MANAGEMENT ================= */
function addToCart(item, quantity) {
  const existing = state.cart.find(c => c.itemId === item.itemId);
  const currentInCart = existing ? existing.quantity : 0;
  const newTotal = currentInCart + quantity;

  if (newTotal > item.remainingStock) {
    alert(`Only ${item.remainingStock} boxes available in stock! (You already have ${currentInCart} in cart)`);
    return;
  }

  if (existing) {
    existing.quantity = newTotal;
  } else {
    state.cart.push({
      itemId: item.itemId,
      itemName: item.itemName,
      category: item.category,
      unitPrice: item.price,
      maxStock: item.remainingStock,
      quantity: quantity
    });
  }

  playSuccessBeep();
  updateCartUI();
}

function updateCartUI() {
  const bar = document.getElementById('floatingCartBar');
  const totalCount = state.cart.length;
  const totalBoxes = state.cart.reduce((sum, i) => sum + i.quantity, 0);
  const totalAmount = state.cart.reduce((sum, i) => sum + (i.unitPrice * i.quantity), 0);

  document.getElementById('cartCountBadge').textContent = totalCount;
  document.getElementById('cartBoxesBadge').textContent = totalBoxes;
  document.getElementById('cartTotalBadge').textContent = totalAmount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  if (totalCount > 0) {
    bar.classList.remove('hidden');
  } else {
    bar.classList.add('hidden');
  }

  renderCartModalItems();
}

function renderCartModalItems() {
  const listEl = document.getElementById('cartItemsList');
  listEl.innerHTML = '';

  const totalBoxes = state.cart.reduce((sum, i) => sum + i.quantity, 0);
  const totalAmount = state.cart.reduce((sum, i) => sum + (i.unitPrice * i.quantity), 0);

  document.getElementById('lblCheckoutCommunity').textContent = state.selectedCommunityName;
  document.getElementById('lblCheckoutBoxes').textContent = totalBoxes;
  document.getElementById('lblCheckoutTotal').textContent = totalAmount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  if (state.cart.length === 0) {
    listEl.innerHTML = '<div class="text-center text-muted py-3">Your bill cart is empty.</div>';
    return;
  }

  state.cart.forEach((item, idx) => {
    const row = document.createElement('div');
    row.className = 'cart-item-row';
    row.innerHTML = `
      <div class="cart-item-info">
        <div class="cart-item-title">${item.itemName}</div>
        <div class="cart-item-sub">₹${item.unitPrice.toFixed(2)} × ${item.quantity} = <strong>₹${(item.unitPrice * item.quantity).toFixed(2)}</strong></div>
      </div>
      <div class="cart-item-actions">
        <button class="stepper-btn btn-cart-minus">-</button>
        <span class="stepper-qty">${item.quantity}</span>
        <button class="stepper-btn btn-cart-plus">+</button>
        <button class="btn-remove-cart" title="Remove Item">🗑️</button>
      </div>
    `;

    row.querySelector('.btn-cart-minus').addEventListener('click', () => {
      if (item.quantity > 1) {
        item.quantity--;
      } else {
        state.cart.splice(idx, 1);
      }
      updateCartUI();
    });

    row.querySelector('.btn-cart-plus').addEventListener('click', () => {
      if (item.quantity < item.maxStock) {
        item.quantity++;
        updateCartUI();
      } else {
        alert(`Cannot exceed remaining physical stock (${item.maxStock} boxes)!`);
      }
    });

    row.querySelector('.btn-remove-cart').addEventListener('click', () => {
      state.cart.splice(idx, 1);
      updateCartUI();
    });

    listEl.appendChild(row);
  });
}

/* ================= CHECKOUT & SALE PROCESSING ================= */
async function submitBill() {
  if (state.cart.length === 0) {
    alert('Please add items to cart before issuing bill.');
    return;
  }

  const custName = document.getElementById('inputCustName').value.trim() || 'Counter Customer';
  const custPhone = document.getElementById('inputCustPhone').value.trim();
  const paymentMode = document.querySelector('input[name="paymentMode"]:checked')?.value || 'Hand Cash';

  const btnSubmit = document.getElementById('btnSubmitBill');
  btnSubmit.disabled = true;
  btnSubmit.innerHTML = '<span>Processing bill & deducting stock...</span>';

  try {
    const payload = {
      communityId: state.selectedCommunityId,
      communityName: state.selectedCommunityName,
      customerName: custName,
      customerPhone: custPhone,
      paymentMode: paymentMode,
      items: state.cart.map(i => ({
        itemId: i.itemId,
        itemName: i.itemName,
        category: i.category,
        unitPrice: i.unitPrice,
        quantity: i.quantity,
        maxStock: i.maxStock
      }))
    };

    let saleRecord;
    if (PhoneStore.isPhoneMode) {
      saleRecord = PhoneStore.processSale(payload);
    } else {
      const res = await fetch('/api/sales', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Failed to process sale');
      }

      saleRecord = await res.json();
    }
    state.currentReceipt = saleRecord;

    // Reset Cart & Inputs
    state.cart = [];
    document.getElementById('inputCustName').value = '';
    document.getElementById('inputCustPhone').value = '';
    updateCartUI();
    closeModal('modalCart');

    // Show Printable Receipt
    renderReceipt(saleRecord);
    openModal('modalReceipt');
    playSuccessBeep();

    // Refresh stock in background
    loadCommunityPricedItems();

  } catch (err) {
    alert(`Error generating bill: ${err.message}`);
  } finally {
    btnSubmit.disabled = false;
    btnSubmit.innerHTML = '<span>🧾 Submit Bill & Subtract Stock</span>';
  }
}

/* ================= RECEIPT RENDERING & ACTIONS ================= */
function renderReceipt(sale) {
  document.getElementById('rBillNo').textContent = sale.billNumber;
  document.getElementById('rDateTime').textContent = sale.createdAt;
  document.getElementById('rCommunity').textContent = sale.communityName || 'General';
  document.getElementById('rPayment').textContent = sale.paymentMode;
  document.getElementById('rCustomer').textContent = sale.customerName || 'Counter Customer';
  document.getElementById('rPhone').textContent = sale.customerPhone || '-';

  const tbody = document.getElementById('rItemsTbody');
  tbody.innerHTML = '';

  let totalBoxes = 0;
  sale.items.forEach(item => {
    totalBoxes += item.quantity;
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td class="col-item">${item.itemName}</td>
      <td class="col-qty">${item.quantity}</td>
      <td class="col-rate">₹${item.unitPrice.toFixed(2)}</td>
      <td class="col-amount">₹${item.totalPrice.toFixed(2)}</td>
    `;
    tbody.appendChild(tr);
  });

  document.getElementById('rTotalBoxes').textContent = totalBoxes;
  document.getElementById('rGrandTotal').textContent = sale.totalAmount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function getReceiptAsText() {
  if (!state.currentReceipt) return '';
  const r = state.currentReceipt;
  let text = `🎆 DIWALI CRACKERS BAZAAR 🎆\n`;
  text += `Invoice: ${r.billNumber}\n`;
  text += `Date: ${r.createdAt}\n`;
  text += `Community: ${r.communityName}\n`;
  text += `Customer: ${r.customerName} (${r.customerPhone || '-'})\n`;
  text += `Payment Mode: ${r.paymentMode}\n`;
  text += `----------------------------------------\n`;
  text += `ITEM | QTY | RATE | AMOUNT\n`;
  text += `----------------------------------------\n`;
  r.items.forEach(i => {
    text += `${i.itemName}\n   ${i.quantity} boxes @ ₹${i.unitPrice} = ₹${i.totalPrice}\n`;
  });
  text += `----------------------------------------\n`;
  text += `GRAND TOTAL: ₹${r.totalAmount.toFixed(2)}\n`;
  text += `✨ Happy & Safe Diwali! ✨\n`;
  return text;
}

/* ================= STOCK & SALES DASHBOARD ================= */
async function loadStockDashboard() {
  try {
    let s;
    let items;
    if (PhoneStore.isPhoneMode) {
      s = PhoneStore.getSummary();
      items = PhoneStore.getItems();
    } else {
      const resSummary = await fetch('/api/dashboard/summary');
      if (resSummary.ok) s = await resSummary.json();
      const resItems = await fetch('/api/items');
      if (resItems.ok) items = await resItems.json();
    }

    if (s) {
      document.getElementById('kpiTotalBoxes').textContent = (s.totalBoxes || 0).toLocaleString();
      document.getElementById('kpiUsedBoxes').textContent = (s.usedBoxes || 0).toLocaleString();
      document.getElementById('kpiRemainingBoxes').textContent = (s.remainingBoxes || 0).toLocaleString();
      document.getElementById('kpiHandCash').textContent = `₹${(s.handCashSales || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
      document.getElementById('kpiPhonePe').textContent = `₹${(s.phonePeSales || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
      document.getElementById('kpiTotalSales').textContent = `₹${(s.totalSales || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
      document.getElementById('kpiBillsCount').textContent = `${s.totalBillsCount || 0} Bills Issued`;
      const elStockComm = document.getElementById('kpiStockTotalCommission');
      if (elStockComm) {
        elStockComm.textContent = `₹${(s.totalCommissionEarned || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
      }
    }

    if (items) {
      renderStockTable(items);
    }
  } catch (err) {
    if (PhoneStore.isPhoneMode) {
      const s = PhoneStore.getSummary();
      const items = PhoneStore.getItems();
      renderStockTable(items);
    } else {
      console.error('Error loading stock dashboard:', err);
    }
  }
}

function renderStockTable(items) {
  const tbody = document.getElementById('tbodyStock');
  const search = document.getElementById('inputStockSearch').value.toLowerCase().trim();

  const filtered = items.filter(i => 
    !search || 
    i.itemName.toLowerCase().includes(search) || 
    (i.itemCode && i.itemCode.toLowerCase().includes(search))
  );

  tbody.innerHTML = '';
  filtered.forEach(item => {
    const tr = document.createElement('tr');
    let badgeClass = 'in-stock';
    if (item.remainingStock <= 0) badgeClass = 'out-of-stock';
    else if (item.remainingStock <= 10) badgeClass = 'low-stock';

    tr.innerHTML = `
      <td><code>${item.itemCode || '-'}</code></td>
      <td><strong>${item.itemName}</strong></td>
      <td><span class="category-badge">${item.category || 'General'}</span></td>
      <td>${item.totalStock}</td>
      <td>${item.usedStock}</td>
      <td><strong>${item.remainingStock}</strong></td>
      <td><span class="stock-badge ${badgeClass}">${item.stockStatus}</span></td>
      <td>
        <button class="btn btn-sm btn-outline btn-restock" data-id="${item.id}" data-name="${item.itemName}">+ Restock</button>
      </td>
    `;
    tbody.appendChild(tr);
  });

  tbody.querySelectorAll('.btn-restock').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      const name = btn.dataset.name;
      const qtyStr = prompt(`How many additional boxes to add for "${name}"?`, '50');
      if (qtyStr) {
        const qty = parseInt(qtyStr);
        if (qty > 0) restockItem(id, qty);
      }
    });
  });
}

document.getElementById('inputStockSearch').addEventListener('input', () => {
  loadStockDashboard();
});

async function restockItem(id, boxes) {
  try {
    const res = await fetch(`/api/items/${id}/restock`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ boxes })
    });
    if (!res.ok) throw new Error('Restock failed');
    alert(`Successfully added ${boxes} boxes!`);
    loadStockDashboard();
    loadCommunityPricedItems();
  } catch (err) {
    alert(`Error: ${err.message}`);
  }
}

/* ================= COMMUNITY & CUSTOM PRICING TAB ================= */
async function loadPricingTab() {
  const selectEl = document.getElementById('selectPricingCommunity');
  const communityId = selectEl.value;
  if (!communityId) return;

  const tbody = document.getElementById('tbodyPricing');
  tbody.innerHTML = '<tr><td colspan="6" class="text-center">Loading community rates...</td></tr>';

  try {
    const res = await fetch(`/api/community-prices?communityId=${communityId}`);
    if (!res.ok) throw new Error('Failed to load prices');
    const items = await res.json();

    const search = document.getElementById('inputPricingSearch').value.toLowerCase().trim();
    const filtered = items.filter(i => !search || i.itemName.toLowerCase().includes(search) || (i.itemCode && i.itemCode.toLowerCase().includes(search)));

    tbody.innerHTML = '';
    filtered.forEach(item => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><code>${item.itemCode || '-'}</code></td>
        <td><strong>${item.itemName}</strong></td>
        <td><span class="category-badge">${item.category}</span></td>
        <td>${item.remainingStock} boxes</td>
        <td>
          <input type="number" step="0.5" min="0" value="${item.price}" class="input-sm input-price-edit" style="width: 110px;" />
        </td>
        <td>
          <button class="btn btn-sm btn-primary btn-save-price" data-id="${item.itemId}">Save</button>
        </td>
      `;
      tbody.appendChild(tr);
    });

    tbody.querySelectorAll('.btn-save-price').forEach(btn => {
      btn.addEventListener('click', async () => {
        const row = btn.closest('tr');
        const priceInput = row.querySelector('.input-price-edit');
        const price = parseFloat(priceInput.value);
        const itemId = parseInt(btn.dataset.id);

        btn.disabled = true;
        btn.textContent = 'Saving...';
        try {
          const res = await fetch('/api/community-prices', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ communityId: parseInt(communityId), itemId, price })
          });
          if (!res.ok) throw new Error('Save failed');
          btn.textContent = 'Saved ✓';
          setTimeout(() => { btn.textContent = 'Save'; btn.disabled = false; }, 1500);
        } catch (e) {
          alert(`Error saving price: ${e.message}`);
          btn.textContent = 'Save';
          btn.disabled = false;
        }
      });
    });

  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="6" class="text-center error-msg">${err.message}</td></tr>`;
  }
}

document.getElementById('selectPricingCommunity').addEventListener('change', loadPricingTab);
document.getElementById('inputPricingSearch').addEventListener('input', loadPricingTab);

/* ================= COMMISSION & SELLING PRICE TAB ================= */
async function loadCommissionTab() {
  const selectEl = document.getElementById('selectCommissionCommunity');
  if (!selectEl) return;
  const communityId = selectEl.value || (state.communities[0] ? state.communities[0].id : null);
  if (!communityId) return;

  const tbody = document.getElementById('tbodyCommission');
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="10" class="text-center">Loading commission and selling prices...</td></tr>';

  try {
    const search = (document.getElementById('inputCommissionSearch')?.value || '').toLowerCase().trim();
    let items;
    if (PhoneStore.isPhoneMode) {
      items = PhoneStore.getCommunityPrices(communityId, search);
    } else {
      const res = await fetch(`/api/commission-list?communityId=${communityId}&search=${encodeURIComponent(search)}`, { cache: 'no-store' });
      if (!res.ok) throw new Error('Failed to load commission list');
      items = await res.json();
    }

    // Summary calculation
    let totalPotential = 0;
    let totalMarginPercentSum = 0;
    let marginCount = 0;

    tbody.innerHTML = '';
    if (items.length === 0) {
      tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted">No crackers found matching your criteria.</td></tr>';
      return;
    }

    items.forEach(item => {
      const commAmount = item.commissionAmount;
      const commPercent = item.commissionPercent;
      const potentialProfit = item.remainingStock > 0 && commAmount > 0 ? (item.remainingStock * commAmount) : 0;
      totalPotential += potentialProfit;

      if (item.costPrice > 0) {
        totalMarginPercentSum += commPercent;
        marginCount++;
      }

      let badgeClass = 'profit-zero';
      let sign = '';
      if (commAmount > 0) {
        badgeClass = 'profit-pos';
        sign = '+';
      } else if (commAmount < 0) {
        badgeClass = 'profit-neg';
      }

      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><code>${item.itemCode || '-'}</code></td>
        <td><strong>${item.itemName}</strong></td>
        <td><span class="category-badge">${item.category || 'General'}</span></td>
        <td><span class="cost-price-tag">₹${item.costPrice.toFixed(2)}</span></td>
        <td>
          <input type="number" step="0.5" min="0" value="${item.sellingPrice}" class="selling-price-input input-selling-edit" data-cost="${item.costPrice}" data-stock="${item.remainingStock}" />
        </td>
        <td>
          <span class="commission-badge ${badgeClass} col-comm-amount">${sign}₹${commAmount.toFixed(2)}</span>
        </td>
        <td>
          <span class="commission-badge ${badgeClass} col-comm-pct">${sign}${commPercent.toFixed(1)}%</span>
        </td>
        <td><strong>${item.remainingStock}</strong> boxes</td>
        <td><span class="col-potential-profit" style="font-weight: 700; color: #b45309;">₹${potentialProfit.toFixed(2)}</span></td>
        <td>
          <button class="btn btn-sm btn-primary btn-save-commission" data-id="${item.itemId}">Save</button>
        </td>
      `;

      // Live recalculation on typing selling price
      const input = tr.querySelector('.input-selling-edit');
      const badgeAmt = tr.querySelector('.col-comm-amount');
      const badgePct = tr.querySelector('.col-comm-pct');
      const potSpan = tr.querySelector('.col-potential-profit');

      input.addEventListener('input', () => {
        const newSelling = parseFloat(input.value) || 0;
        const cost = parseFloat(input.dataset.cost) || 0;
        const stock = parseInt(input.dataset.stock) || 0;
        const diff = newSelling - cost;
        const pct = cost > 0 ? (diff / cost) * 100 : 0;
        const newPotential = stock > 0 && diff > 0 ? (stock * diff) : 0;

        let cls = 'profit-zero';
        let sgn = '';
        if (diff > 0) { cls = 'profit-pos'; sgn = '+'; }
        else if (diff < 0) { cls = 'profit-neg'; }

        badgeAmt.className = `commission-badge ${cls} col-comm-amount`;
        badgeAmt.textContent = `${sgn}₹${diff.toFixed(2)}`;

        badgePct.className = `commission-badge ${cls} col-comm-pct`;
        badgePct.textContent = `${sgn}${pct.toFixed(1)}%`;

        potSpan.textContent = `₹${newPotential.toFixed(2)}`;
      });

      // Save button
      const btnSave = tr.querySelector('.btn-save-commission');
      btnSave.addEventListener('click', async () => {
        const newPrice = parseFloat(input.value);
        if (isNaN(newPrice) || newPrice < 0) {
          alert('Please enter a valid selling price.');
          return;
        }

        btnSave.disabled = true;
        btnSave.textContent = 'Saving...';
        try {
          if (PhoneStore.isPhoneMode) {
            PhoneStore.setCommunityPrice(parseInt(communityId), item.itemId, newPrice);
          } else {
            const saveRes = await fetch('/api/community-prices', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                communityId: parseInt(communityId),
                itemId: item.itemId,
                price: newPrice
              })
            });
            if (!saveRes.ok) throw new Error('Save failed');
          }
          navigator.vibrate?.(30);
          btnSave.textContent = 'Saved ✓';
          setTimeout(() => {
            btnSave.textContent = 'Save';
            btnSave.disabled = false;
          }, 1500);

          // Update billing prices in background
          if (state.selectedCommunityId === parseInt(communityId)) {
            loadCommunityPricedItems();
          }
        } catch (err) {
          alert(`Error saving selling price: ${err.message}`);
          btnSave.textContent = 'Save';
          btnSave.disabled = false;
        }
      });

      tbody.appendChild(tr);
    });

    // Update Commission KPI Cards
    const avgMargin = marginCount > 0 ? (totalMarginPercentSum / marginCount) : 0;
    const elPotential = document.getElementById('kpiCommPotential');
    if (elPotential) elPotential.textContent = `₹${totalPotential.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;

    const elAvg = document.getElementById('kpiCommAvgMargin');
    if (elAvg) elAvg.textContent = `${avgMargin >= 0 ? '+' : ''}${avgMargin.toFixed(1)}%`;

    // Fetch earned commission from completed sales
    if (PhoneStore.isPhoneMode) {
      const summary = PhoneStore.getSummary();
      const elEarned = document.getElementById('kpiCommTotalEarned');
      if (elEarned) elEarned.textContent = `₹${(summary.totalCommissionEarned || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
    } else {
      const resSummary = await fetch('/api/dashboard/summary', { cache: 'no-store' });
      if (resSummary.ok) {
        const summary = await resSummary.json();
        const elEarned = document.getElementById('kpiCommTotalEarned');
        if (elEarned) elEarned.textContent = `₹${(summary.totalCommissionEarned || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
      }
    }

  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="10" class="text-center error-msg">${err.message}</td></tr>`;
  }
}

document.getElementById('inputCommissionSearch')?.addEventListener('input', loadCommissionTab);
document.getElementById('btnRefreshCommission')?.addEventListener('click', () => {
  loadCommissionTab();
  navigator.vibrate?.(20);
});

/* ================= SRI VIJAYALAXMI QUOTATION NO. 1137 MODAL & DOWNLOAD ================= */
async function loadQuotationModal() {
  const tbody = document.getElementById('tbodyQuotationItems');
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="9" class="text-center">Loading Quotation 1137 items...</td></tr>';

  // Find Sri Vijayalaxmi community ID or fall back to current community
  const targetComm = state.communities.find(c => c.name.includes('Sri Vijayalaxmi') || c.name.includes('1137')) || state.communities[0];
  const commId = targetComm ? targetComm.id : 1;

  try {
    const res = await fetch(`/api/commission-list?communityId=${commId}`, { cache: 'no-store' });
    if (!res.ok) throw new Error('Failed to load quotation');
    const items = await res.json();

    let totalPieces = 0;
    let totalCostSum = 0;
    let totalSellingSum = 0;
    let totalCommissionSum = 0;

    tbody.innerHTML = '';
    items.forEach((item, index) => {
      const pieces = item.remainingStock || 0;
      const costRate = item.costPrice || 0;
      const sellPrice = item.sellingPrice || 0;
      const commAmount = item.commissionAmount || (sellPrice - costRate);
      const commPct = item.commissionPercent || (costRate > 0 ? (commAmount / costRate) * 100 : 0);
      const totalItemSales = pieces * sellPrice;
      const totalItemCost = pieces * costRate;
      const totalItemProfit = pieces * commAmount;

      totalPieces += pieces;
      totalCostSum += totalItemCost;
      totalSellingSum += totalItemSales;
      totalCommissionSum += totalItemProfit;

      let cls = 'profit-zero';
      let sgn = '';
      if (commAmount > 0) { cls = 'profit-pos'; sgn = '+'; }
      else if (commAmount < 0) { cls = 'profit-neg'; }

      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${index + 1}</td>
        <td><strong>${item.itemName}</strong></td>
        <td><span class="category-badge">${item.category}</span></td>
        <td>${Math.ceil(pieces / 10)}</td>
        <td><strong>${pieces}</strong></td>
        <td>₹${costRate.toFixed(2)}</td>
        <td><strong>₹${sellPrice.toFixed(2)}</strong></td>
        <td><span class="commission-badge ${cls}">${sgn}₹${commAmount.toFixed(2)}</span></td>
        <td><span class="commission-badge ${cls}">${sgn}${commPct.toFixed(1)}%</span></td>
      `;
      tbody.appendChild(tr);
    });

    document.getElementById('qSumPieces').textContent = totalPieces.toLocaleString();
    document.getElementById('qSumCost').textContent = `₹${totalCostSum.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
    document.getElementById('qSumSelling').textContent = `₹${totalSellingSum.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
    document.getElementById('qSumCommission').textContent = `₹${totalCommissionSum.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;

    openModal('modalQuotationPdf');
  } catch (err) {
    alert(`Error loading quotation: ${err.message}`);
  }
}

async function downloadQuotationCsv() {
  const targetComm = state.communities.find(c => c.name.includes('Sri Vijayalaxmi') || c.name.includes('1137')) || state.communities[0];
  const commId = targetComm ? targetComm.id : 1;

  try {
    const res = await fetch(`/api/commission-list?communityId=${commId}`, { cache: 'no-store' });
    if (!res.ok) throw new Error('Failed to fetch items');
    const items = await res.json();

    let csv = "No.,Particulars,Category,Pieces / Stock,Cost Price (Rs),Selling Price (Rs),Commission Amount (Rs),Commission Margin (%)\n";
    items.forEach((item, index) => {
      const cleanName = `"${item.itemName.replace(/"/g, '""')}"`;
      csv += `${index + 1},${cleanName},"${item.category}",${item.remainingStock},${item.costPrice},${item.sellingPrice},${item.commissionAmount},${item.commissionPercent}%\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'Sri_Vijayalaxmi_Quotation_1137.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    navigator.vibrate?.(30);
  } catch (err) {
    alert(`Error exporting CSV: ${err.message}`);
  }
}

document.getElementById('btnViewQuotationPdf')?.addEventListener('click', loadQuotationModal);
document.getElementById('btnDownloadQuotationCsv')?.addEventListener('click', downloadQuotationCsv);
document.getElementById('btnDownloadQuotationCsvModal')?.addEventListener('click', downloadQuotationCsv);
document.getElementById('btnCloseQuotationPdf')?.addEventListener('click', () => closeModal('modalQuotationPdf'));
document.getElementById('btnCloseQuotationPdfBtn')?.addEventListener('click', () => closeModal('modalQuotationPdf'));
document.getElementById('btnPrintQuotationPdf')?.addEventListener('click', () => window.print());

document.getElementById('btnShareQuotationWhatsapp')?.addEventListener('click', () => {
  const text = `🎆 SRI VIJAYALAXMI FIRE WORKS 🎆\nQuotation No: 1137 | Customer: Gangadhar Reddy\nDate: 12/10/2026\nTotal 106 Cracker Varieties with Verified Rates.\nOpen live POS catalog: https://calibration-mysterious-minds-worth.trycloudflare.com`;
  window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`, '_blank');
});

document.getElementById('btnCopyPublicUrl')?.addEventListener('click', () => {
  const url = document.getElementById('lblPublicUrl').textContent;
  navigator.clipboard.writeText(url).then(() => alert('Anywhere Secure Online Link copied to clipboard!'));
});

document.getElementById('btnSharePublicWhatsapp')?.addEventListener('click', () => {
  const url = document.getElementById('lblPublicUrl').textContent;
  const text = `🎆 Diwali Crackers POS Mobile App 🎆\nOpen this link on your phone (on ANY Wi-Fi or 4G/5G):\n${url}\n\nTip: In Chrome tap ⋮ (Menu) -> 'Install app' or 'Add to Home screen' to install!`;
  window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`, '_blank');
});

/* ================= MASTER CATALOG TAB ================= */
async function loadCatalogTab() {
  const tbody = document.getElementById('tbodyCatalog');
  tbody.innerHTML = '<tr><td colspan="7" class="text-center">Loading master catalog...</td></tr>';

  try {
    const res = await fetch('/api/items');
    if (!res.ok) throw new Error('Failed to load items');
    const items = await res.json();

    tbody.innerHTML = '';
    items.forEach(item => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><code>${item.itemCode || '-'}</code></td>
        <td><strong>${item.itemName}</strong></td>
        <td><span class="category-badge">${item.category}</span></td>
        <td>₹${item.defaultPrice.toFixed(2)}</td>
        <td>${item.totalStock}</td>
        <td><strong>${item.remainingStock}</strong></td>
        <td>
          <button class="btn btn-sm btn-outline btn-restock-cat" data-id="${item.id}" data-name="${item.itemName}">+ Boxes</button>
        </td>
      `;
      tbody.appendChild(tr);
    });

    tbody.querySelectorAll('.btn-restock-cat').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.dataset.id;
        const name = btn.dataset.name;
        const qtyStr = prompt(`Add extra boxes for "${name}":`, '50');
        if (qtyStr) {
          const qty = parseInt(qtyStr);
          if (qty > 0) {
            restockItem(id, qty).then(() => loadCatalogTab());
          }
        }
      });
    });

  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="7" class="text-center error-msg">${err.message}</td></tr>`;
  }
}

/* ================= SALES HISTORY TAB ================= */
async function loadSalesHistory(filter = 'All') {
  const tbody = document.getElementById('tbodyHistory');
  tbody.innerHTML = '<tr><td colspan="7" class="text-center">Loading sales records...</td></tr>';

  try {
    let records;
    if (PhoneStore.isPhoneMode) {
      records = PhoneStore.getSalesHistory(filter);
    } else {
      const res = await fetch(`/api/sales?filter=${encodeURIComponent(filter)}`);
      if (!res.ok) throw new Error('Failed to load history');
      records = await res.json();
    }

    tbody.innerHTML = '';
    if (records.length === 0) {
      tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No sales records found.</td></tr>';
      return;
    }

    records.forEach(sale => {
      const tr = document.createElement('tr');
      const isPhonePe = sale.paymentMode === 'PhonePe';
      tr.innerHTML = `
        <td><code>${sale.billNumber}</code></td>
        <td>${sale.createdAt}</td>
        <td>${sale.customerName || 'Walk-in'}</td>
        <td><span class="category-badge">${sale.communityName || 'General'}</span></td>
        <td><span class="receipt-payment-badge" style="color: ${isPhonePe ? '#5F259F' : '#059669'}; font-weight: bold;">${sale.paymentMode}</span></td>
        <td><strong>₹${sale.totalAmount.toFixed(2)}</strong></td>
        <td>
          <button class="btn btn-sm btn-outline btn-view-bill" data-id="${sale.id}">Reprint 🖨️</button>
        </td>
      `;
      tbody.appendChild(tr);
    });

    tbody.querySelectorAll('.btn-view-bill').forEach(btn => {
      btn.addEventListener('click', async () => {
        const saleId = parseInt(btn.dataset.id);
        const record = records.find(r => r.id === saleId);
        if (!record) return;

        // Fetch items
        const resItems = await fetch(`/api/sales/${saleId}/items`);
        if (resItems.ok) {
          record.items = await resItems.json();
        }
        state.currentReceipt = record;
        renderReceipt(record);
        openModal('modalReceipt');
      });
    });

  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="7" class="text-center error-msg">${err.message}</td></tr>`;
  }
}

// History Filter pills
document.querySelectorAll('.history-filters .filter-pill').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.history-filters .filter-pill').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    loadSalesHistory(btn.dataset.filter);
  });
});

/* ================= MODAL INITIALIZATION & EVENTS ================= */
function openModal(id) {
  document.getElementById(id)?.classList.remove('hidden');
}

function closeModal(id) {
  document.getElementById(id)?.classList.add('hidden');
}

function initModals() {
  // Cart Modal
  document.getElementById('btnOpenCartModal')?.addEventListener('click', () => openModal('modalCart'));
  document.getElementById('btnCloseCart')?.addEventListener('click', () => closeModal('modalCart'));
  document.getElementById('btnCancelCart')?.addEventListener('click', () => closeModal('modalCart'));
  document.getElementById('btnClearCart')?.addEventListener('click', () => {
    if (confirm('Are you sure you want to clear this entire bill cart?')) {
      state.cart = [];
      updateCartUI();
      closeModal('modalCart');
    }
  });

  // Submit Bill
  document.getElementById('btnSubmitBill')?.addEventListener('click', submitBill);

  // Receipt Modal actions
  document.getElementById('btnCloseReceipt')?.addEventListener('click', () => closeModal('modalReceipt'));
  document.getElementById('btnReceiptNext')?.addEventListener('click', () => closeModal('modalReceipt'));

  document.getElementById('btnReceiptPrint')?.addEventListener('click', () => {
    window.print();
  });

  document.getElementById('btnReceiptCopy')?.addEventListener('click', () => {
    const text = getReceiptAsText();
    navigator.clipboard.writeText(text).then(() => {
      alert('Receipt copied to clipboard!');
    });
  });

  document.getElementById('btnReceiptWhatsApp')?.addEventListener('click', () => {
    const text = getReceiptAsText();
    const phone = state.currentReceipt?.customerPhone || '';
    const cleanPhone = phone.replace(/[^0-9]/g, '');
    const url = cleanPhone.length >= 10
      ? `https://api.whatsapp.com/send?phone=91${cleanPhone.slice(-10)}&text=${encodeURIComponent(text)}`
      : `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  });

  // Network Info Modal
  document.getElementById('btnNetworkInfo')?.addEventListener('click', () => openModal('modalNetwork'));
  document.getElementById('btnCloseNetwork')?.addEventListener('click', () => closeModal('modalNetwork'));
  document.getElementById('btnCloseNetworkBtn')?.addEventListener('click', () => closeModal('modalNetwork'));
  document.getElementById('btnCopyPhoneUrl')?.addEventListener('click', () => {
    const url = document.getElementById('lblPhoneUrl').textContent;
    navigator.clipboard.writeText(url).then(() => alert('Phone URL copied to clipboard!'));
  });

  // New Community Modal
  const openNewComm = () => openModal('modalNewCommunity');
  document.getElementById('btnNewCommunityQuick')?.addEventListener('click', openNewComm);
  document.getElementById('btnCreateCommunityModal')?.addEventListener('click', openNewComm);
  document.getElementById('btnCloseNewCommunity')?.addEventListener('click', () => closeModal('modalNewCommunity'));
  document.getElementById('btnCancelNewCommunity')?.addEventListener('click', () => closeModal('modalNewCommunity'));

  document.getElementById('btnSaveNewCommunity')?.addEventListener('click', async () => {
    const name = document.getElementById('inputNewCommName').value.trim();
    const desc = document.getElementById('inputNewCommDesc').value.trim();
    if (!name) return alert('Please enter a community name.');

    try {
      const res = await fetch('/api/communities', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, description: desc })
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Failed to save');
      }
      alert(`Community "${name}" created!`);
      closeModal('modalNewCommunity');
      document.getElementById('inputNewCommName').value = '';
      document.getElementById('inputNewCommDesc').value = '';
      await loadCommunities();
    } catch (e) {
      alert(`Error: ${e.message}`);
    }
  });

  // Add Item to Catalog Modal
  document.getElementById('btnOpenNewItemModal')?.addEventListener('click', () => openModal('modalNewItem'));
  document.getElementById('btnCloseNewItem')?.addEventListener('click', () => closeModal('modalNewItem'));
  document.getElementById('btnCancelNewItem')?.addEventListener('click', () => closeModal('modalNewItem'));

  document.getElementById('btnSaveNewItem')?.addEventListener('click', async () => {
    const name = document.getElementById('inputNewItemName').value.trim();
    const code = document.getElementById('inputNewItemCode').value.trim();
    const cat = document.getElementById('inputNewItemCat').value.trim();
    const stock = parseInt(document.getElementById('inputNewItemStock').value) || 0;
    const price = parseFloat(document.getElementById('inputNewItemPrice').value) || 0;

    if (!name) return alert('Item name is required.');
    if (stock <= 0) return alert('Initial boxes must be greater than 0.');

    try {
      const res = await fetch('/api/items', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, code, category: cat, totalBoxes: stock, defaultPrice: price })
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Failed to save item');
      }
      alert(`Item "${name}" added to master inventory!`);
      closeModal('modalNewItem');
      document.getElementById('inputNewItemName').value = '';
      document.getElementById('inputNewItemCode').value = '';
      loadCatalogTab();
      loadCommunityPricedItems();
    } catch (e) {
      alert(`Error: ${e.message}`);
    }
  });

  // Refresh Stock button
  document.getElementById('btnRefreshStock')?.addEventListener('click', () => {
    loadStockDashboard();
    alert('Stock and KPI numbers refreshed!');
  });

  // Retry Terminal Server Connection button
  document.getElementById('btnRetryServer')?.addEventListener('click', async () => {
    const btn = document.getElementById('btnRetryServer');
    if (btn) btn.textContent = 'Connecting...';
    await fetchNetworkInfo();
    if (btn) btn.textContent = '🔄 Check Server Connection';
  });

  // Switch to Standalone Phone Mode (Runs on phone without PC)
  document.getElementById('btnSwitchToPhoneMode')?.addEventListener('click', async () => {
    await PhoneStore.init();
    await loadCommunities();
    await loadCommunityPricedItems();
    alert('📱 Standalone Phone Mode Activated!\nYou can now bill, track stock, and generate receipts with zero PC required.');
  });
}
