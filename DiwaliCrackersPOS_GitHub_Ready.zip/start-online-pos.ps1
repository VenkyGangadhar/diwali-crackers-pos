# Start POS Server and Cloudflare Tunnel for Anywhere Access
$Host.UI.RawUI.WindowTitle = "Diwali Crackers POS - Anywhere Access (Any Wi-Fi / 4G / 5G)"
Clear-Host

Write-Host '==================================================================' -ForegroundColor Yellow
Write-Host '   DIWALI CRACKERS POS - ONLINE / ANYWHERE ACCESS                 ' -ForegroundColor Yellow
Write-Host '==================================================================' -ForegroundColor Yellow
Write-Host ''
Write-Host '[1/3] Starting Local POS Backend...' -ForegroundColor Cyan

$serverDir = 'C:\Users\venky\.gemini\antigravity\scratch\CrackerBillingWeb'
Set-Location $serverDir

# Start Web Server process
$serverExe = "$serverDir\publish\CrackerBillingWeb.exe"
if (Test-Path $serverExe) {
    $serverProc = Start-Process -FilePath $serverExe -PassThru -WindowStyle Hidden
} else {
    $serverProc = Start-Process -FilePath "dotnet" -ArgumentList "run" -PassThru -WindowStyle Hidden
}

Write-Host '[2/3] Connecting to Cloudflare Secure Tunnel...' -ForegroundColor Cyan

# Start cloudflared and capture output
$logFile = "$serverDir\tunnel.log"
if (Test-Path $logFile) { Remove-Item $logFile -Force }

$cfProc = Start-Process -FilePath "$serverDir\cloudflared.exe" `
    -ArgumentList "tunnel", "--url", "http://localhost:5000", "--logfile", "`"$logFile`"" `
    -PassThru -WindowStyle Hidden

Write-Host '[3/3] Waiting for your secure online link...' -ForegroundColor Cyan

$tunnelUrl = $null
$stopwatch = [System.Diagnostics.Stopwatch]::StartNew()

while ($stopwatch.ElapsedMilliseconds -lt 25000) {
    Start-Sleep -Milliseconds 800
    if (Test-Path $logFile) {
        $content = Get-Content $logFile -Raw -ErrorAction SilentlyContinue
        if ($content -match '(https://[a-zA-Z0-9-]+\.trycloudflare\.com)') {
            $tunnelUrl = $matches[1]
            break
        }
    }
}

if ($tunnelUrl) {
    Set-Clipboard -Value $tunnelUrl
    Write-Host ''
    Write-Host '==================================================================' -ForegroundColor Green
    Write-Host ' SUCCESS! YOUR SECURE ONLINE LINK IS READY:                       ' -ForegroundColor Green
    Write-Host ''
    Write-Host "    $tunnelUrl" -ForegroundColor Yellow -BackgroundColor Black
    Write-Host ''
    Write-Host ' (This link has been automatically COPIED to your clipboard!)     ' -ForegroundColor White
    Write-Host '==================================================================' -ForegroundColor Green
    Write-Host ''
    Write-Host 'HOW TO USE FROM ANY PHONE (ON ANY WI-FI OR 4G/5G):' -ForegroundColor Cyan
    Write-Host '  1. Send this link to your phone (via WhatsApp, SMS, or Email)' -ForegroundColor White
    Write-Host '  2. Open it in Google Chrome on your Android phone' -ForegroundColor White
    Write-Host '  3. Tap Chrome Menu (3 dots) -> Install app or Add to Home screen' -ForegroundColor White
    Write-Host '  4. Bill customers from ANYWHERE! All sales sync live with this PC.' -ForegroundColor White
    Write-Host ''
    Write-Host 'Keep this window open while you are using the app.' -ForegroundColor DarkYellow
    Write-Host 'Press Ctrl+C to stop the server.' -ForegroundColor Gray

    # Open in PC browser as well
    Start-Process $tunnelUrl

    # Keep script alive until Ctrl+C or process exits
    try {
        while (-not $cfProc.HasExited) {
            Start-Sleep -Seconds 1
        }
    } finally {
        Stop-Process -Id $serverProc.Id -Force -ErrorAction SilentlyContinue
        Stop-Process -Id $cfProc.Id -Force -ErrorAction SilentlyContinue
    }
} else {
    Write-Host '[ERROR] Could not generate online link. Check internet connection.' -ForegroundColor Red
    Stop-Process -Id $serverProc.Id -Force -ErrorAction SilentlyContinue
    Stop-Process -Id $cfProc.Id -Force -ErrorAction SilentlyContinue
    pause
}
